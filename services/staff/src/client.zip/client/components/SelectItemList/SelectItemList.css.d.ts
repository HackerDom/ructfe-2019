export const item: string;
export const selected: string;
export const itemCircle: string;
