export const tabs: string;
export const tab: string;
export const selectedTab: string;
