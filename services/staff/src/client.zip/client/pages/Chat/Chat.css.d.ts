export const chat: string;
export const chatName: string;
export const chatSender: string;
export const messagesContainer: string;
export const messages: string;
export const message: string;
export const messageText: string;
