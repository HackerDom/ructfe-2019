export const marginBox: string;
export const alignCenter: string;
