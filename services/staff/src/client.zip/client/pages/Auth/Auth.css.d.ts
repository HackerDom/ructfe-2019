export const auth: string;
export const form: string;
