export const registerButton: string;
