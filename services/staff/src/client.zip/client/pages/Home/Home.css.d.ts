export const red: string;
