import React from 'react';
import s from './Home.css';

export function Home () {
    return <span className={s.red}>{'Hello, world'}</span>;
}
