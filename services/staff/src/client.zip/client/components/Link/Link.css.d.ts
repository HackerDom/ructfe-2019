export const link: string;
