export const text: string;
