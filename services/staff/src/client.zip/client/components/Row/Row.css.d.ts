export const row: string;
export const leftElementContainer: string;
export const leftElement: string;
export const rightElement: string;
