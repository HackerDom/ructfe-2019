import React from 'react';
import s from './UsersSearching.css';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import { TextField, Link } from '@material-ui/core';
import { Button } from '../../components/Button/Button';
import { Row } from '../../components/Row/Row';
import { Text } from '../../components/Text/Text';
import { Input } from '../../components/Input/Input';
import { MarginBox } from '../../components/MarginBox/MarginBox';
import { BorderBox } from '../../components/BorderBox/BorderBox';
import { login } from '../../models/login';
import { search } from '../../models/search';
import { Redirect } from 'react-router'

export class UsersSearching extends React.Component {
    constructor (props) {
        super(props);
        this.state = {
            username: '',
            id: '',
            firstName: '',
            lastName: ''
        };
    }

    changeLastName = (value) => {
        search.lastName = value;
        this.setState({ lastName: value });
    }

    changeFirstName = (value) => {
        search.firstName = value;
        this.setState({ firstName: value });
    }

    onSearch = () => {
        search
            .search()
            .then(x => this.setState({ id: x.id.toString(), username: x.username.toString() }));
    };

    render () {
        const FORM_GAP = 110;
        return (<article className={s.formContainer}>
            <section>
                <Text text="Search user with: " style={{ fontSize: '24px', fontWeight: 'bold' }} />
                <section>
                    <MarginBox>
                        <Row gap={FORM_GAP}>
                            <Text text="First name" />
                            <Input
                                onChange={this.changeFirstName}
                                value={this.state.firstName}
                            />
                        </Row>
                    </MarginBox>
                    <MarginBox>
                        <Row gap={FORM_GAP}>
                            <Text text="Last name" />
                            <Input
                                onChange={this.changeLastName}
                                value={this.state.lastName}
                            />
                        </Row>
                    </MarginBox>

                    <MarginBox>
                    </MarginBox>
                    <Button text="Search" onClick={this.onSearch} />
                    <MarginBox>
                    </MarginBox>
                </section>
                {
                    this.state.id !== ''
                        ? <BorderBox>
                            <MarginBox>
                                <Row gap={FORM_GAP}>
                                    <Text text={'First name: '}/>
                                    <Text text={this.state.firstName}/>
                                </Row>
                            </MarginBox>
                            <MarginBox>
                                <Row gap={FORM_GAP}>
                                    <Text text={'Last name: '}/>
                                    <Text text={this.state.lastName}/>
                                </Row>
                            </MarginBox>
                            <MarginBox>
                                <Row gap={FORM_GAP}>
                                    <Text text={'Username'}/>
                                    <Text text={this.state.username}/>
                                </Row>
                            </MarginBox>
                            <MarginBox>
                                <Button onClick={() => <Redirect to="/chats" />}>
                                    {`Go to user ${this.state.username}`}
                                </Button>
                                <Row gap={FORM_GAP}>
                                    <Text text={'Id'}/>
                                    <Text text={this.state.id}/>
                                </Row>
                            </MarginBox>
                        </BorderBox> : null
                }
            </section>
        </article>
        );
    }
}
