export const input: string;
