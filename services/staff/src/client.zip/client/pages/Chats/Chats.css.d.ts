export const chats: string;
export const chatsNames: string;
export const divider: string;
export const chatCreation: string;
