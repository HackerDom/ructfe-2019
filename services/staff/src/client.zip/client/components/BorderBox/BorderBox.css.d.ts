export const boarderBox: string;
