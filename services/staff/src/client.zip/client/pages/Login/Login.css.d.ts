export const loginButton: string;
